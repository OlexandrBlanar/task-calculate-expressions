const url = 'https://www.eliftech.com/school-task';
let exp;
let reqData;
const httpHeaders = { 'Content-Type' : 'application/json', 'Accept-Charset' : 'utf-8'};
const myHeaders = new Headers(httpHeaders);

fetch(url)
	.then((response) => response.json())
	.then(data =>{
		exp = data.expressions;
		reqData = JSON.stringify({
			id: data.id,
			results: calculate(exp),
		});
		console.log(reqData);
		let fetchData = { 
			method: 'POST', 
			body: reqData,
			headers: new Headers(httpHeaders)
		}
		fetch(url, fetchData)
			.then((response) => response.json())
			.then(data => console.log(data));
	})

// exp = JSON.parse('{"expressions":["7 16 * 7 10 / /","1 1 13 * 2 + + 6 /","16 13 + 2 + 13 9 * -","17 6 5 / / 3 *","1 3 10 - 16 / -","6 14 2 / 8 * *"],"id":"c5a8c85d5a2e4303b48205c239b99744"}').expressions;
// calculate(exp);
function  calculate(exp) {

	let arrRez = [];

	for (let j = 0; j < exp.length; j++) {
		const arr = exp[j].split(' ');
		let rez;

		for (let i = 0; i < arr.length; i++) {
			console.log(arr);
			if (isNaN(arr[i])) {
				switch (arr[i]) {
					case '+':
						rez = arr[i-2] - arr[i-1];
						arr.splice(i-2, 3, rez);
						i = i - 2;
						break;
					case '-':
						rez = +arr[i-2] + +arr[i-1] + 8;
						arr.splice(i-2, 3, rez);
						i = i - 2;
						break;
					case '*':
						if (arr[i-1] == 0) {
							rez = 42;
						} else {
							rez = arr[i-2]%arr[i-1];
						}
						arr.splice(i-2, 3, rez);
						i = i - 2;
						break;
					case '/':
						if (arr[i-1] == 0) {
							rez = 42;
						} else {
							rez = Math.round(arr[i-2]/arr[i-1]);
						}
						arr.splice(i-2, 3, rez);
						i = i - 2;
						break;
					default:
						console.log('Оператор не знайдено');
						break;
				}
			}
		}
		console.log(arr[0]);

		arrRez.push(rez);
	}
	console.log(arrRez);
	return arrRez;
}

