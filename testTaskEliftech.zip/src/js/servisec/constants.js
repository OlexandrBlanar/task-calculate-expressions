export const url = 'https://www.eliftech.com/school-task';
export const httpHeaders = { 'Content-Type' : 'application/json', 'Accept-Charset' : 'utf-8'};