import Servisec from './servisec/service';

const dataServisec = new Servisec();

document.getElementById('getExpressions').addEventListener('click', () => {
    dataServisec.getExp()
    .then(data => document.getElementById('expressions').innerText = data)
});

document.getElementById('postResult').addEventListener('click', () => {
    document.getElementById('result').innerText = dataServisec.calculateExp();
});

document.getElementById('verify').addEventListener('click', () => {
    dataServisec.postResult()
        .then(data => document.getElementById('verifyResult').innerText = data.passed)
});
