# rxjs-demo

1. git clone https://github.com/Oneia/rxjs-demo.git
2. cd rxjs-demo
3. npm i
4. npm start
5. navigate to http://localhost:8080/
